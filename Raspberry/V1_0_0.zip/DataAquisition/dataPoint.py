# ========================================================================
# Title:        DataPoint
# Author:       Jonas Buuck
# Date:         04.03.2021
# Description:  Class to describe a dataPoint
#
# --< LOG >-----
# 04.03.2021 -> class created by Jonas
# 05.03.2021 -> __string__ added
# ========================================================================


class DataPoint:

    def __init__(self, x, y, rssi):
        self.x = x
        self.y = y
        self.rssi = rssi

    def __str__(self):
        return ("@[" + str(x) + "] [" + str(y) + "] : " + str(rssi) + " dBm / " + str(round(10**(rssi/10),2)) + " mW")