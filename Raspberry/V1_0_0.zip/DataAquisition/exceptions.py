class NoNetworksFoundException(Exception):
    pass

class RssiValueTransmissionException(Exception):
    pass

class SsidLengthException(Exception):
    pass