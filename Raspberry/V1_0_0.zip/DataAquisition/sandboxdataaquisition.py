
from colorama import Fore, Back, Style

print(Fore.RED + 'some red text') 